
import { GoogleGenAI, Type } from "@google/genai";

export const analyzeScreenshot = async (imageBase64: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: imageBase64, mimeType: 'image/jpeg' } },
          { text: `Return JSON: {"lastTime":"HH:mm:ss","lastMultiplier":"num","lastRoundId":"id"}` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            lastTime: { type: Type.STRING },
            lastMultiplier: { type: Type.STRING },
            lastRoundId: { type: Type.STRING },
          },
          required: ["lastTime", "lastMultiplier"]
        }
      }
    });

    let text = response.text || "{}";
    if (text.startsWith("```")) {
      text = text.replace(/^```json\s*/, "").replace(/^```\s*/, "").replace(/\s*```$/, "");
    }
    return text;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("ERREUR CRITIQUE : Capture illisible ou problème API.");
  }
};

export const analyzeDirectSeed = async (imageBase64: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: imageBase64, mimeType: 'image/jpeg' } },
          { text: `Analyse cette capture d'écran de la fenêtre "Détails de la manche" (Provably Fair).
          1. Extrait le multiplicateur final de la manche (ex: 8.65).
          2. Extrait le multiplicateur de la manche précédente dans l'historique affiché (juste en dessous ou à côté).
          3. Extrait l'heure précise (HH:mm:ss).
          4. Extrait l'ID de la manche.
          
          Retourne UNIQUEMENT ce format JSON : 
          {"mainMultiplier": "8.65", "prevMultiplier": "1.42", "currentTime": "14:20:05", "roundId": "id_string"}` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mainMultiplier: { type: Type.STRING },
            prevMultiplier: { type: Type.STRING },
            currentTime: { type: Type.STRING },
            roundId: { type: Type.STRING },
          },
          required: ["mainMultiplier", "currentTime"]
        }
      }
    });

    let text = response.text || "{}";
    if (text.startsWith("```")) {
      text = text.replace(/^```json\s*/, "").replace(/^```\s*/, "").replace(/\s*```$/, "");
    }
    return text;
  } catch (error) {
    console.error("Gemini Direct Analysis Error:", error);
    throw new Error("ERREUR PROTOCOLE : Capture invalide. Assurez-vous de scanner la fenêtre des détails de la manche (Provably Fair).");
  }
};

export const chatWithAssistant = async (message: string, history: {role: string, content: string}[]): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history.map(h => ({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.content }]
        })),
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: `Vous êtes l'Expert IA d'Aloka Fotsy, spécialisé dans le protocole Direct Seed Scan (SHA-512). 
        Répondez de manière technique et précise sur les calculs probabilistes.`
      }
    });
    return response.text || "Le noyau IA est indisponible.";
  } catch (error: any) {
    console.error("Gemini Chat Error:", error);
    throw new Error(error.message || "Erreur de communication.");
  }
};

export const translateContent = async (text: string, targetLang: string = "Malagasy"): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Translate to ${targetLang}: ${text}`,
    });
    return response.text || "";
  } catch (error) {
    return "Fadisoana.";
  }
};
