
import React, { useState, useEffect, lazy, Suspense } from 'react';
import { 
  Terminal, X, ShieldCheck, LogOut, LayoutGrid, Menu, Activity, Headset, Zap, Loader2,
  Fingerprint, ChevronRight, AlertTriangle, Settings, Shield, Server, CheckCircle2, Globe, Cpu,
  CreditCard, Phone, MessageSquare
} from 'lucide-react';
import { AppState } from './types.ts';
import { PLATFORMS } from './constants.ts';
import { ToastProvider, useToast } from './components/ToastProvider.tsx';

const HomeView = lazy(() => import('./components/HomeView.tsx'));
const DashboardView = lazy(() => import('./components/DashboardView.tsx'));
const ScreenshotView = lazy(() => import('./components/ScreenshotView.tsx'));
const DirectAnalysisView = lazy(() => import('./components/DirectAnalysisView.tsx'));
const HistoryView = lazy(() => import('./components/HistoryView.tsx'));
const AssistantView = lazy(() => import('./components/AssistantView.tsx'));
const LiveChatView = lazy(() => import('./components/LiveChatView.tsx'));
const SettingsView = lazy(() => import('./components/SettingsView.tsx'));
const MethodologyView = lazy(() => import('./components/MethodologyView.tsx'));
const AboutView = lazy(() => import('./components/AboutView.tsx'));
const ProfileView = lazy(() => import('./components/ProfileView.tsx'));
const WallpaperSelectorView = lazy(() => import('./components/WallpaperSelectorView.tsx'));

const VALID_CODES = ['210405', '160808'];
const DEFAULT_WALLPAPER = "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?q=80&w=2070&auto=format&fit=crop";

const AppContent: React.FC = () => {
  const { showToast } = useToast();
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  
  const [state, setState] = useState<AppState & { isPredictorUnlocked: boolean, registeredUsers: {id: string, pass: string}[] }>(() => {
    try {
      const saved = localStorage.getItem('aloka_nexus_v11_web_final');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) { console.error("Restore state error", e); }
    
    return {
      isAuthenticated: false,
      isVerified: true,
      hasAcceptedWallpaper: false,
      hasSeenSubscription: false,
      currentUser: null,
      currentView: 'home',
      syncedPlatform: null,
      syncedEngine: null,
      syncedGame: 'Aviator',
      theme: 'orange' as any,
      predictions: [],
      dashboardHistory: [],
      isPredictorUnlocked: false,
      registeredUsers: [{ id: 'ADMIN', pass: 'ALOKA2025' }],
      customWallpaper: DEFAULT_WALLPAPER,
      isLightBg: false
    };
  });

  const [showSyncModal, setShowSyncModal] = useState(false);
  const [selectedPlatformId, setSelectedPlatformId] = useState<string | null>(null);
  const [selectedGameType, setSelectedGameType] = useState<'spribe' | 'studio' | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [loginId, setLoginId] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [regId, setRegId] = useState('');
  const [regPass, setRegPass] = useState('');
  const [activationCode, setActivationCode] = useState('');

  useEffect(() => {
    localStorage.setItem('aloka_nexus_v11_web_final', JSON.stringify(state));
  }, [state]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanId = loginId.toUpperCase().trim();
    const user = state.registeredUsers.find(u => u.id === cleanId);
    
    if (user && user.pass === loginPass) {
      setState(prev => ({ ...prev, isAuthenticated: true, currentUser: user.id }));
      showToast("IDENTIFICATION RÉUSSIE", "success");
    } else {
      showToast("ID ou mot de passe incorrect.", "error");
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!VALID_CODES.includes(activationCode)) {
      showToast("Code d'activation incorrect.", "error");
      return;
    }
    const cleanId = regId.toUpperCase().trim();
    if (state.registeredUsers.some(u => u.id === cleanId)) {
      showToast("Cet ID existe déjà.", "error");
      return;
    }

    const newUser = { id: cleanId, pass: regPass };
    setState(prev => ({ 
      ...prev, 
      registeredUsers: [...prev.registeredUsers, newUser] 
    }));
    showToast("Profil créé avec succès.", "success");
    setAuthMode('login'); 
  };

  const updateCredentials = (newId: string, newPass: string) => {
    const cleanId = newId.toUpperCase().trim();
    setState(prev => {
      const updatedUsers = prev.registeredUsers.map(user => 
        user.id === prev.currentUser ? { id: cleanId, pass: newPass } : user
      );
      return {
        ...prev,
        currentUser: cleanId,
        registeredUsers: updatedUsers
      };
    });
  };

  const acceptWallpaper = (wallpaper: string | null) => {
    setState(prev => ({ 
      ...prev, 
      customWallpaper: wallpaper || DEFAULT_WALLPAPER, 
      hasAcceptedWallpaper: true 
    }));
    showToast("ENVIRONNEMENT INITIALISÉ", "success");
  };

  const acknowledgeSubscription = () => {
    setState(prev => ({ ...prev, hasSeenSubscription: true }));
    showToast("TERMES ACCEPTÉS", "info");
  };

  const navigateTo = (view: string) => {
    setIsMobileMenuOpen(false);
    if (view === 'screenshot' && !state.syncedPlatform) {
      showToast("Veuillez d'abord lier un vecteur serveur.", "warning");
      openSyncModal();
      return;
    }
    setState(prev => ({ ...prev, currentView: view }));
  };

  const openSyncModal = () => {
    setSelectedPlatformId(state.syncedPlatform);
    setSelectedGameType(state.syncedEngine === 'Spribe' ? 'spribe' : 'studio');
    setShowSyncModal(true);
  };

  const handleActivation = () => {
    if (!selectedPlatformId || !selectedGameType) return;
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setState(prev => ({
        ...prev,
        isPredictorUnlocked: true,
        syncedPlatform: selectedPlatformId,
        syncedEngine: selectedGameType === 'spribe' ? 'Spribe' : 'Studio'
      }));
      setShowSyncModal(false);
      showToast("SYNC OK - MODULE PRÊT", "success");
      navigateTo('screenshot');
    }, 1500);
  };

  return (
    <div className={`min-h-screen flex flex-col relative overflow-hidden font-sans ${state.isLightBg ? 'light-wallpaper' : ''}`}>
      {/* FOND D'ÉCRAN DYNAMIQUE */}
      <div className="fixed inset-0 z-0 bg-black">
        <div className="absolute inset-0 bg-cover bg-center transition-all duration-1000" style={{ backgroundImage: `url(${state.customWallpaper || DEFAULT_WALLPAPER})` }} />
        <div className={`absolute inset-0 ${state.isLightBg ? 'bg-white/40 backdrop-blur-sm' : 'bg-black/60 backdrop-blur-sm'}`} />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen w-full">
        {!state.hasAcceptedWallpaper ? (
          <div className="flex-1 flex items-center justify-center p-4">
             <WallpaperSelectorView 
               onBack={() => {}} 
               onSelect={acceptWallpaper} 
               currentWallpaper={state.customWallpaper}
               isFirstLaunch={true}
             />
          </div>
        ) : !state.hasSeenSubscription ? (
          <div className="flex-1 flex items-center justify-center p-4 animate-scale-in">
             <div className="w-full max-w-lg glass-card rounded-[3rem] border border-white/10 p-10 space-y-8 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-[0.05] pointer-events-none">
                  <CreditCard className="w-48 h-48 text-kls-orange" />
                </div>
                
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-kls-orange/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-kls-orange/30">
                    <ShieldCheck className="w-8 h-8 text-kls-orange animate-pulse" />
                  </div>
                  <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Conditions de <span className="text-kls-orange">Service VIP</span></h2>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.3em]">Abonnement Hebdomadaire Aloka Neural</p>
                </div>

                <div className="space-y-6">
                  <div className="bg-white/5 p-6 rounded-3xl border border-white/5 space-y-4">
                    <div className="flex justify-between items-center">
                       <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Premier Accès</span>
                       <span className="text-sm font-black text-white uppercase">25 000 FMG / 1 €</span>
                    </div>
                    <div className="h-px bg-white/5 w-full"></div>
                    <div className="flex justify-between items-center">
                       <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Renouvellement</span>
                       <span className="text-sm font-black text-kls-orange uppercase">12 500 FMG / 0.60 € / Semaine</span>
                    </div>
                    <p className="text-[9px] text-rose-500 font-black uppercase text-center mt-2 animate-pulse">Paiement obligatoire le dimanche à l'avance</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                     <a href="tel:+261379594257" className="p-5 bg-orange-500/10 border border-orange-500/20 rounded-2xl flex flex-col items-center gap-2 group hover:bg-orange-500/20 transition-all">
                        <Phone className="w-5 h-5 text-orange-500 group-hover:scale-110 transition-transform" />
                        <span className="text-[8px] font-black text-orange-500 uppercase tracking-widest">Orange Money</span>
                        <span className="text-[10px] font-black text-white">+261 37 95 942 57</span>
                     </a>
                     <a href="tel:+261336756185" className="p-5 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex flex-col items-center gap-2 group hover:bg-rose-500/20 transition-all">
                        <Phone className="w-5 h-5 text-rose-500 group-hover:scale-110 transition-transform" />
                        <span className="text-[8px] font-black text-rose-500 uppercase tracking-widest">Airtel Money</span>
                        <span className="text-[10px] font-black text-white">+261 33 67 561 85</span>
                     </a>
                  </div>

                  <div className="text-center">
                    <p className="text-[9px] text-slate-500 font-bold uppercase mb-4">Bénéficiaire : Mahandry Hery RANDRIAMALALA</p>
                    <button 
                      onClick={acknowledgeSubscription}
                      className="w-full h-16 bg-white text-black font-black rounded-2xl uppercase text-xs shadow-xl hover:bg-gray-100 transition-all active:scale-95"
                    >
                      J'accepte les conditions
                    </button>
                  </div>
                </div>
             </div>
          </div>
        ) : !state.isAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-4 animate-scale-in">
            <div className="w-full max-md p-8 glass-card rounded-[3rem] border-none shadow-2xl relative overflow-hidden">
              <div className="text-center mb-8">
                 <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/5">
                   <Fingerprint className="w-8 h-8 text-kls-cyan animate-pulse" />
                 </div>
                 <h2 className="text-xl font-black text-white uppercase tracking-tighter">ALOKA <span className="text-kls-cyan">NEXUS</span></h2>
                 <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.4em] mt-1">v11.0 Elite Portal</p>
              </div>

              <div className="space-y-6">
                <div className="flex p-1 bg-black/40 rounded-xl">
                  <button onClick={() => setAuthMode('login')} className={`flex-1 py-3 text-[10px] font-black uppercase rounded-lg transition-all ${authMode === 'login' ? 'bg-white text-black shadow-lg' : 'text-slate-500'}`}>Connexion</button>
                  <button onClick={() => setAuthMode('register')} className={`flex-1 py-3 text-[10px] font-black uppercase rounded-lg transition-all ${authMode === 'register' ? 'bg-white text-black shadow-lg' : 'text-slate-500'}`}>S'inscrire</button>
                </div>
                
                {authMode === 'login' ? (
                  <form onSubmit={handleLogin} className="space-y-4">
                    <input type="text" placeholder="ID OPÉRATEUR" value={loginId} onChange={e => setLoginId(e.target.value)} className="w-full h-14 px-6 bg-white/5 border border-white/5 rounded-2xl text-white outline-none focus:bg-white/10 transition-all uppercase font-black text-sm tracking-widest" required />
                    <input type="password" placeholder="MOT DE PASSE" value={loginPass} onChange={e => setLoginPass(e.target.value)} className="w-full h-14 px-6 bg-white/5 border border-white/5 rounded-2xl text-white outline-none focus:bg-white/10 transition-all font-black text-sm" required />
                    <button type="submit" className="w-full h-16 bg-white text-black font-black rounded-2xl uppercase text-xs shadow-xl hover:bg-gray-100 active:scale-95 transition-all mt-4">Accéder au Noyau</button>
                  </form>
                ) : (
                  <form onSubmit={handleRegister} className="space-y-4">
                    <input type="text" placeholder="CHOISIR UN ID" value={regId} onChange={e => setRegId(e.target.value)} className="w-full h-14 px-6 bg-white/5 border border-white/5 rounded-2xl text-white outline-none focus:bg-white/10 transition-all font-black uppercase text-sm" required />
                    <input type="password" placeholder="MOT DE PASSE" value={regPass} onChange={e => setRegPass(e.target.value)} className="w-full h-14 px-6 bg-white/5 border border-white/5 rounded-2xl text-white outline-none focus:bg-white/10 transition-all font-black text-sm" required />
                    <input type="text" placeholder="CODE ACTIVATION" value={activationCode} onChange={e => setActivationCode(e.target.value)} className="w-full h-14 px-6 bg-kls-cyan/10 border border-kls-cyan/20 rounded-2xl text-white text-center font-black placeholder:text-kls-cyan/40 tracking-[0.3em]" required />
                    <button type="submit" className="w-full h-16 bg-white text-black font-black rounded-2xl uppercase text-xs shadow-xl hover:bg-gray-200 active:scale-95 transition-all mt-4">Créer Profil Elite</button>
                  </form>
                )}
              </div>
            </div>
          </div>
        ) : (
          <>
            <header className="h-16 sticky top-0 z-[60] bg-black/40 backdrop-blur-xl border-none px-6 flex items-center justify-between">
              <div className="flex items-center gap-3 cursor-pointer group" onClick={() => navigateTo('home')}>
                <Terminal className="w-5 h-5 text-white group-hover:text-kls-cyan transition-colors" />
                <span className="text-xs font-black text-white uppercase tracking-tighter">ALOKA <span className="text-kls-cyan">NEXUS</span></span>
              </div>
              <nav className="hidden lg:flex items-center gap-1">
                 {[
                   { id: 'home', label: 'Dashboard', icon: LayoutGrid },
                   { id: 'screenshot', label: 'Predictor', icon: Zap },
                   { id: 'direct_analysis', label: 'Direct Scan', icon: ShieldCheck },
                   { id: 'dashboard', label: 'Analytics', icon: Activity },
                   { id: 'chat', label: 'Support', icon: Headset },
                   { id: 'settings', label: 'Config', icon: Settings },
                 ].map(v => (
                   <button key={v.id} onClick={() => navigateTo(v.id)} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${state.currentView === v.id ? 'bg-white text-black shadow-md' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
                     <v.icon className="w-3.5 h-3.5" />
                     <span>{v.label}</span>
                   </button>
                 ))}
              </nav>
              <div className="flex items-center gap-3">
                <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden p-2 hover:bg-white/5 rounded-lg transition-colors"><Menu className="w-5 h-5 text-white" /></button>
                <button onClick={() => setState(prev => ({...prev, isAuthenticated: false}))} className="p-2 text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all"><LogOut className="w-4 h-4" /></button>
              </div>
            </header>
            
            <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full relative z-10">
              <Suspense fallback={<div className="flex items-center justify-center h-64"><Loader2 className="w-10 h-10 animate-spin text-white/20" /></div>}>
                  {state.currentView === 'home' && <HomeView state={state} onNavigate={navigateTo} syncPlatform={openSyncModal} />}
                  {state.currentView === 'dashboard' && <DashboardView onBack={() => navigateTo('home')} />}
                  {state.currentView === 'chat' && <LiveChatView onBack={() => navigateTo('home')} currentUser={state.currentUser} />}
                  {state.currentView === 'ai' && <AssistantView onBack={() => navigateTo('home')} />}
                  {state.currentView === 'screenshot' && <ScreenshotView onBack={() => navigateTo('home')} state={state} addPrediction={p => setState(s => ({...s, predictions: [p, ...s.predictions]}))} onSwitchPlatform={openSyncModal} />}
                  {state.currentView === 'direct_analysis' && <DirectAnalysisView onBack={() => navigateTo('home')} state={state} addPrediction={p => setState(s => ({...s, predictions: [p, ...s.predictions]}))} />}
                  {state.currentView === 'history' && <HistoryView onBack={() => navigateTo('home')} predictions={state.predictions} clearHistory={() => setState(s => ({...s, predictions: []}))} />}
                  {state.currentView === 'settings' && <SettingsView onBack={() => navigateTo('home')} state={state} onNavigate={navigateTo} changeTheme={() => {}} />}
                  {state.currentView === 'profile' && <ProfileView onBack={() => navigateTo('settings')} state={state} updateCredentials={updateCredentials} />}
                  {state.currentView === 'wallpaper' && <WallpaperSelectorView onBack={() => navigateTo('settings')} onSelect={w => setState(s => ({...s, customWallpaper: w}))} currentWallpaper={state.customWallpaper} />}
                  {state.currentView === 'methodology' && <MethodologyView onBack={() => navigateTo('settings')} />}
                  {state.currentView === 'about' && <AboutView onBack={() => navigateTo('settings')} />}
              </Suspense>
            </main>
          </>
        )}
      </div>

      {/* MODAL DE SYNCHRONISATION (VECTEUR PLATEFORME) */}
      {showSyncModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in">
           <div className="w-full max-w-lg glass-card rounded-[3rem] border-none overflow-hidden shadow-2xl animate-scale-in">
              <div className="bg-slate-950/80 p-8 border-b border-white/5 flex justify-between items-center">
                 <div className="flex items-center gap-4">
                    <Server className="w-6 h-6 text-kls-cyan" />
                    <div>
                      <h2 className="text-xl font-black text-white uppercase tracking-tighter">Liaison <span className="text-kls-cyan">Vecteur</span></h2>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Initialisation de la plateforme de jeu</p>
                    </div>
                 </div>
                 <button onClick={() => setShowSyncModal(false)} className="p-3 bg-white/5 rounded-2xl hover:bg-rose-500/20 text-slate-500 hover:text-rose-500 transition-all">
                    <X className="w-5 h-5" />
                 </button>
              </div>

              <div className="p-8 space-y-8 overflow-y-auto max-h-[70vh] custom-scrollbar">
                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">Sélectionner la Plateforme</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                       {PLATFORMS.map((p) => (
                         <button 
                           key={p.id}
                           disabled={p.disabled}
                           onClick={() => setSelectedPlatformId(p.id)}
                           className={`p-4 rounded-3xl border-2 flex flex-col items-center gap-3 transition-all ${p.disabled ? 'opacity-20 grayscale cursor-not-allowed' : selectedPlatformId === p.id ? 'bg-white/10 border-kls-cyan scale-105 shadow-lg' : 'bg-white/5 border-transparent opacity-60 hover:opacity-100 hover:bg-white/10'}`}
                         >
                            <img src={p.logo} className="w-12 h-12 object-contain" alt={p.name} />
                            <span className="text-[10px] font-black text-white uppercase tracking-widest text-center">{p.name}</span>
                            {selectedPlatformId === p.id && <CheckCircle2 className="w-4 h-4 text-kls-cyan" />}
                         </button>
                       ))}
                    </div>
                 </div>

                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">Configuration du Moteur</label>
                    <div className="grid grid-cols-2 gap-4">
                       {[
                         { id: 'spribe', label: 'Spribe Aviator', icon: Zap },
                         { id: 'studio', label: 'Studio Live', icon: Cpu, isAnomaly: true }
                       ].map((e) => (
                         <button 
                           key={e.id}
                           onClick={() => setSelectedGameType(e.id as any)}
                           className={`p-5 rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all ${selectedGameType === e.id ? 'bg-white/10 border-kls-orange scale-105' : 'bg-white/5 border-transparent opacity-60 hover:opacity-100'}`}
                         >
                            <e.icon className={`w-5 h-5 ${selectedGameType === e.id ? 'text-kls-orange' : 'text-slate-500'}`} />
                            <span className="text-[10px] font-black text-white uppercase tracking-widest">{e.label}</span>
                            {e.isAnomaly && <span className="text-[7px] text-rose-500 font-black animate-pulse uppercase">ANOMALIE FLUX</span>}
                         </button>
                       ))}
                    </div>
                 </div>

                 {isVerifying ? (
                    <div className="py-6 flex flex-col items-center justify-center space-y-4 bg-slate-900/60 rounded-3xl animate-pulse">
                       <Loader2 className="w-10 h-10 text-kls-cyan animate-spin" />
                       <p className="text-[10px] font-black text-kls-cyan uppercase tracking-[0.3em]">Établissement du lien neural...</p>
                    </div>
                 ) : (
                    <button 
                      onClick={handleActivation}
                      disabled={!selectedPlatformId || !selectedGameType}
                      className="w-full h-16 bg-white text-black rounded-3xl flex items-center justify-center gap-4 text-sm font-black uppercase shadow-2xl hover:bg-gray-100 transition-all group active:scale-95 disabled:opacity-30 disabled:grayscale"
                    >
                      <Zap className="w-6 h-6 fill-black group-hover:scale-110 transition-transform" />
                      Activer la Synchronisation
                    </button>
                 )}
              </div>
           </div>
        </div>
      )}

      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl flex flex-col p-6 animate-fade-in lg:hidden">
           <div className="flex justify-between items-center mb-8">
             <span className="text-xs font-black text-white uppercase tracking-widest">Menu Tactique</span>
             <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 bg-white/5 rounded-xl"><X className="w-5 h-5 text-white" /></button>
           </div>
           <div className="grid grid-cols-1 gap-3">
              {[
                 { id: 'home', label: 'Dashboard', icon: LayoutGrid },
                 { id: 'screenshot', label: 'Predictor', icon: Zap },
                 { id: 'direct_analysis', label: 'Direct Scan', icon: ShieldCheck },
                 { id: 'dashboard', label: 'Télémétrie', icon: Activity },
                 { id: 'chat', label: 'Support VIP', icon: Headset },
                 { id: 'settings', label: 'Config', icon: Settings },
              ].map(v => (
                <button key={v.id} onClick={() => navigateTo(v.id)} className="flex items-center justify-between p-5 bg-white/5 rounded-2xl border-none">
                   <div className="flex items-center gap-4">
                     <v.icon className={`w-5 h-5 ${state.currentView === v.id ? 'text-kls-cyan' : 'text-slate-500'}`} />
                     <span className="text-xs font-black text-white uppercase tracking-tight">{v.label}</span>
                   </div>
                   <ChevronRight className="w-4 h-4 text-slate-700" />
                </button>
              ))}
           </div>
        </div>
      )}
    </div>
  );
};

const App: React.FC = () => <ToastProvider><AppContent /></ToastProvider>;
export default App;
