
import React, { useState, useRef, useEffect } from 'react';
import { 
  ChevronLeft, Upload, RefreshCcw, Loader2, Activity,
  ShieldCheck, Copy, Clock, Gauge, Camera, X, RotateCcw, Sparkles
} from 'lucide-react';
import { analyzeDirectSeed } from '../services/gemini.ts';
import { Prediction, AppState, ColorSignal } from '../types.ts';
import { useToast } from './ToastProvider.tsx';

interface DirectAnalysisViewProps {
  onBack: () => void;
  state: AppState;
  addPrediction: (p: Prediction) => void;
}

const generateHash = () => {
  const chars = '0123456789abcdef';
  return Array.from({ length: 128 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
};

const DirectAnalysisView: React.FC<DirectAnalysisViewProps> = ({ onBack, state, addPrediction }) => {
  const { showToast } = useToast();
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const calculateDirectResult = (mainMult: string, prevMult: string, baseTime: string) => {
    const getDecimal = (num: string) => {
      const f = parseFloat(num);
      return isNaN(f) ? 0.5 : f - Math.floor(f);
    };
    const d1 = getDecimal(mainMult);
    const d2 = prevMult ? getDecimal(prevMult) : 0.45;
    const Pt = ((d1 + d2) / 2) * (0.8 + 0.4 * ((d1 * d2) % 1));
    const finalMultVal = Pt > 0.4 ? 3 + Math.sqrt(d1 * d2 * 10) : 1.00 + (Pt * 7);
    const resMult = Math.max(1.00, finalMultVal).toFixed(2);
    
    const timeParts = baseTime.split(':');
    const date = new Date();
    date.setHours(parseInt(timeParts[0]) || 0, parseInt(timeParts[1]) || 0, parseInt(timeParts[2]) || 0);
    date.setSeconds(date.getSeconds() + Math.round((d1 + d2) * 120));
    
    return { 
      resTime: date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
      resMult,
      confidence: Math.min(Math.floor(85 + (d1 * 14)), 99)
    };
  };

  const runAnalysis = async (imgData: string) => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const base64 = imgData.split('base64,')[1];
      const jsonStr = await analyzeDirectSeed(base64);
      const data = JSON.parse(jsonStr);
      if (!data.mainMultiplier || !data.currentTime) throw new Error("Données illisibles.");
      
      const { resTime, resMult, confidence } = calculateDirectResult(data.mainMultiplier, data.prevMultiplier || "", data.currentTime);
      const p: Prediction = {
        id: Date.now().toString(),
        platform: 'DIRECT_SEED',
        timestamp: new Date().toISOString(),
        inputTime: data.currentTime,
        inputMultiplier: data.mainMultiplier,
        mode: 'DIRECT',
        hash: generateHash(),
        results: { res1: { time: resTime, multiplier: resMult, label: 'SIGNAL UNITÉ', confidence } },
        audit: { roundId: data.roundId || "SEED-MATRIX" }
      };
      setPrediction(p);
      addPrediction(p);
      showToast("ANALYSE SHA-512 RÉUSSIE", "success");
    } catch (err: any) {
      setAnalysisError(err.message);
      showToast("Erreur Protocole", "error");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => { setImage(null); setAnalysisError(null); setPrediction(null); };

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto px-4">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 glass-card p-6 rounded-3xl border-none shadow-xl">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-3 bg-white/5 rounded-2xl text-emerald-400 active:scale-95 transition-all"><ChevronLeft className="w-5 h-5" /></button>
          <div>
            <h1 className="text-lg font-black text-white uppercase tracking-tighter italic">DIRECT <span className="text-emerald-400">SEED SCAN</span></h1>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Protocole Matrix v11.0</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 rounded-xl">
           <ShieldCheck className="w-4 h-4 text-emerald-500" />
           <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Workflow Isolé</span>
        </div>
      </header>

      {!prediction ? (
        <div className="space-y-6 animate-slide-up">
          <div className="p-6 glass-card border-none bg-emerald-500/5 rounded-3xl">
            <p className="text-[10px] text-slate-400 font-bold uppercase leading-relaxed tracking-widest text-center">Capturez la fenêtre "Détails de la manche" pour extraire la Seed SHA-512.</p>
          </div>

          <div className={`glass-card h-[380px] border-2 border-dashed rounded-3xl relative overflow-hidden flex flex-col items-center justify-center transition-all duration-500 ${image || isCameraActive ? 'border-emerald-500/40 shadow-2xl' : 'border-white/10 hover:border-emerald-500/30'}`}>
            {isCameraActive ? (
              <div className="relative w-full h-full">
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4">
                  <button onClick={() => {
                    const canvas = canvasRef.current;
                    const video = videoRef.current;
                    if (canvas && video) {
                      canvas.width = video.videoWidth; canvas.height = video.videoHeight;
                      canvas.getContext('2d')?.drawImage(video, 0, 0);
                      const dataUrl = canvas.toDataURL('image/jpeg');
                      setImage(dataUrl); setIsCameraActive(false); 
                      if (video.srcObject) (video.srcObject as MediaStream).getTracks().forEach(t => t.stop());
                      runAnalysis(dataUrl);
                    }
                  }} className="w-16 h-16 bg-white rounded-full flex items-center justify-center active:scale-90 shadow-xl"><div className="w-12 h-12 rounded-full border-4 border-black"></div></button>
                  <button onClick={() => { setIsCameraActive(false); if (videoRef.current?.srcObject) (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop()); }} className="w-16 h-16 bg-rose-500 text-white rounded-full flex items-center justify-center active:scale-90 shadow-xl"><X className="w-8 h-8" /></button>
                </div>
              </div>
            ) : analysisError ? (
              <div className="p-8 text-center space-y-6">
                <Loader2 className="w-12 h-12 text-rose-500 mx-auto" />
                <p className="text-[10px] text-rose-500/80 font-bold uppercase">{analysisError}</p>
                <div className="flex flex-col gap-2">
                  <button onClick={() => image && runAnalysis(image)} className="h-12 bg-white text-black rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2"><RotateCcw className="w-4 h-4" /> Réessayer</button>
                  <button onClick={reset} className="h-12 bg-white/5 rounded-xl text-[10px] font-black uppercase text-slate-500">Abandonner</button>
                </div>
              </div>
            ) : image ? (
              <div className="relative w-full h-full p-8">
                <img src={image} className={`w-full h-full object-contain rounded-2xl ${isAnalyzing ? 'opacity-40 blur-sm' : ''}`} alt="" />
                {isAnalyzing && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4">
                    <Loader2 className="w-12 h-12 text-emerald-400 animate-spin" />
                    <span className="text-[10px] font-black uppercase text-emerald-400 animate-pulse tracking-widest">Extraction SHA-512...</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center space-y-10 p-8">
                <div className="flex justify-center gap-6">
                  <button onClick={() => fileInputRef.current?.click()} className="w-20 h-20 rounded-2xl bg-emerald-500/10 flex items-center justify-center hover:bg-emerald-500/20 transition-all shadow-xl"><Upload className="w-10 h-10 text-emerald-500" /></button>
                  <button onClick={async () => {
                    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                    if (videoRef.current) { videoRef.current.srcObject = stream; setIsCameraActive(true); }
                  }} className="w-20 h-20 rounded-2xl bg-emerald-500/10 flex items-center justify-center hover:bg-emerald-500/20 transition-all shadow-xl"><Camera className="w-10 h-10 text-emerald-500" /></button>
                </div>
                <div>
                  <h3 className="text-base font-black text-white uppercase">Neural Matrix Scanner</h3>
                  <p className="text-[9px] text-slate-500 font-bold uppercase mt-1">Capturez le détail Provably Fair</p>
                </div>
              </div>
            )}
            <input type="file" ref={fileInputRef} onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const reader = new FileReader();
                reader.onloadend = () => { setImage(reader.result as string); runAnalysis(reader.result as string); };
                reader.readAsDataURL(file);
              }
            }} className="hidden" />
            <canvas ref={canvasRef} className="hidden" />
          </div>
        </div>
      ) : (
        <div className="space-y-6 animate-reveal-data">
          {/* RESULT BOX - ENRICHED APPEARANCE */}
          <div className="glass-card p-10 rounded-3xl border-none bg-slate-950/90 shadow-[0_0_50px_rgba(16,185,129,0.1)] relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent"></div>
            
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8 border-b border-white/5 pb-8 mb-8 animate-reveal-data" style={{ animationDelay: '100ms' }}>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                   <span className="text-[11px] font-black text-emerald-500 uppercase tracking-[0.3em]">Signature Seed Vérifiée</span>
                </div>
                <h2 className="text-xl font-black text-white uppercase italic tracking-tight">UNITÉ <span className="text-emerald-400">NEURAL TACTIQUE</span></h2>
              </div>
              <div className="flex gap-4">
                <div className="p-4 bg-emerald-500/10 rounded-2xl text-center min-w-[120px]">
                  <span className="block text-[9px] font-black text-emerald-400 uppercase mb-1 tracking-widest">Confiance IA</span>
                  <span className="text-lg font-black text-white">{prediction.results.res1.confidence}%</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
               <div className="space-y-4 animate-reveal-data" style={{ animationDelay: '300ms' }}>
                  <div className="flex items-center gap-3 ml-2">
                    <Clock className="w-5 h-5 text-slate-500" />
                    <span className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Calcul Horaire</span>
                  </div>
                  <div className="p-8 bg-slate-900 rounded-3xl flex items-center justify-center shadow-inner group-hover:bg-slate-800 transition-colors">
                    <span className="text-3xl font-black text-white font-mono tracking-widest text-glow-animate">{prediction.results.res1.time}</span>
                  </div>
               </div>
               <div className="space-y-4 animate-reveal-data" style={{ animationDelay: '500ms' }}>
                  <div className="flex justify-between items-center ml-2">
                    <div className="flex items-center gap-3">
                      <Gauge className="w-5 h-5 text-emerald-400" />
                      <span className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Signal SHA-512</span>
                    </div>
                    <button onClick={() => { navigator.clipboard.writeText(prediction.results.res1.multiplier); showToast("COPIÉ", "info"); }} className="p-2 bg-white/5 rounded-lg hover:bg-white/10 transition-all"><Copy className="w-4 h-4 text-emerald-400" /></button>
                  </div>
                  <div className={`p-8 rounded-3xl flex items-center justify-center transition-all duration-1000 animate-hologram ${parseFloat(prediction.results.res1.multiplier) >= 3 ? 'bg-emerald-500/20' : 'bg-slate-900'}`}>
                    <div className="flex items-baseline gap-2">
                       <span className="text-4xl font-black text-white font-mono text-glow-animate tracking-tighter">{prediction.results.res1.multiplier}</span>
                       <span className="text-2xl font-black text-emerald-400 italic">x</span>
                    </div>
                  </div>
               </div>
            </div>

            <div className="mt-8 p-6 bg-black/70 rounded-3xl flex items-center gap-6 shadow-inner animate-reveal-data" style={{ animationDelay: '700ms' }}>
               <Sparkles className="w-6 h-6 text-emerald-500 shrink-0 animate-spin-slow" />
               <p className="text-[10px] text-slate-500 uppercase font-bold leading-relaxed tracking-tight">
                 Algorithme Seed-Scan v11 stabilisé. Retrait suggéré à <span className="text-emerald-400 font-black">{prediction.results.res1.multiplier}x</span>.
               </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-6 animate-reveal-data" style={{ animationDelay: '800ms' }}>
             <button onClick={reset} className="flex-1 h-16 bg-emerald-600 text-white rounded-2xl flex items-center justify-center gap-4 text-[11px] font-black uppercase shadow-xl hover:scale-[1.02] active:scale-95 transition-all">
               <RotateCcw className="w-5 h-5" /> RE-SCANNER SHA-512
             </button>
             <button onClick={onBack} className="flex-1 h-16 bg-white/5 text-slate-400 rounded-2xl flex items-center justify-center gap-4 text-[11px] font-black uppercase hover:bg-white/10 transition-all">
               RETOUR
             </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default React.memo(DirectAnalysisView);
