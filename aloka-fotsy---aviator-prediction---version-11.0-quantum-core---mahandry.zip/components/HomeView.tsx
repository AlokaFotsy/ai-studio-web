
import React from 'react';
import { 
  Activity, Camera, History, Zap, ArrowUpRight, 
  UserCog, MessageSquare, Settings, Shield, Globe, Cpu, Server, 
  RefreshCw, Wifi, Lock, Database, PlayCircle, BarChart2, Headset, Sparkles,
  FileKey, ShieldCheck, AlertTriangle, CreditCard, Phone
} from 'lucide-react';
import { AppState } from '../types.ts';
import { PLATFORMS } from '../constants.ts';

interface HomeViewProps {
  state: AppState;
  onNavigate: (view: string) => void;
  syncPlatform: () => void;
}

const HomeView: React.FC<HomeViewProps> = ({ state, onNavigate, syncPlatform }) => {
  const activePlatform = PLATFORMS.find(p => p.id === state.syncedPlatform);
  const today = new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });

  return (
    <div className="space-y-6 animate-fade-in pb-24">
      
      {/* 1. TOP SYSTEM STATUS BAR */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-slate-900/50 p-4 rounded-3xl border border-white/5 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em]">Flux Neural Actif</span>
          <div className="h-3 w-px bg-white/10 mx-2"></div>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Wifi className="w-3 h-3" /> 8ms Latence
          </span>
        </div>
        <div className="flex items-center gap-4">
           {state.syncedEngine === 'Studio' && (
             <div className="flex items-center gap-2 px-3 py-1 bg-rose-500/10 rounded-lg border border-rose-500/20">
                <AlertTriangle className="w-3 h-3 text-rose-500 animate-pulse" />
                <span className="text-[8px] font-black text-rose-500 uppercase">ANOMALIE STUDIO DÉTECTÉE</span>
             </div>
           )}
           <div className="flex items-center gap-2 px-3 py-1 bg-kls-cyan/10 rounded-lg border border-kls-cyan/20">
              <Sparkles className="w-3 h-3 text-kls-cyan" />
              <span className="text-[9px] font-black text-kls-cyan uppercase tracking-widest">Mise à jour : {today}</span>
           </div>
        </div>
      </div>

      {/* 2. VIP SUBSCRIPTION STATUS BAR (NEW) */}
      <div className="glass-card p-6 rounded-[2.5rem] border-kls-orange/20 bg-kls-orange/5 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden group">
         <div className="absolute top-0 right-0 p-6 opacity-[0.03] pointer-events-none group-hover:scale-110 transition-transform">
           <CreditCard className="w-32 h-32 text-kls-orange" />
         </div>
         <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-kls-orange/20 flex items-center justify-center border border-kls-orange/30">
              <CreditCard className="w-6 h-6 text-kls-orange" />
            </div>
            <div className="space-y-1">
               <h4 className="text-xs font-black text-white uppercase tracking-tight">Statut de l'Abonnement Hebdomadaire</h4>
               <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Paiement : 12 500 FMG / Semaine (Dimanche)</p>
            </div>
         </div>
         <div className="flex items-center gap-4 z-10">
            <a href="tel:+261379594257" className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[9px] font-black text-white uppercase flex items-center gap-2 hover:bg-white/10 transition-all">
               <Phone className="w-3 h-3 text-kls-orange" /> Orange Money
            </a>
            <a href="tel:+261336756185" className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[9px] font-black text-white uppercase flex items-center gap-2 hover:bg-white/10 transition-all">
               <Phone className="w-3 h-3 text-rose-500" /> Airtel Money
            </a>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 3. MAIN NEURAL CORE (Launch Predictor) */}
        <div className="lg:col-span-2 relative group cursor-pointer" onClick={() => onNavigate('screenshot')}>
          <div className="absolute inset-0 bg-gradient-to-r from-kls-orange/20 to-transparent blur-2xl rounded-[3rem] opacity-50 group-hover:opacity-80 transition-opacity"></div>
          <div className="glass-card h-full min-h-[320px] rounded-[3rem] border-white/10 p-8 sm:p-10 relative overflow-hidden flex flex-col justify-between hover:border-kls-orange/30 transition-all duration-500 animate-pulse-quantum">
            
            <div className="absolute top-0 right-0 p-10 opacity-[0.05] pointer-events-none">
              <Camera className="w-64 h-64" />
            </div>
            
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[10px] bg-kls-orange/20 blur-xl rotate-45 animate-scan pointer-events-none"></div>

            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-kls-orange rounded-full shadow-lg shadow-kls-orange/20 mb-6">
                <Zap className="w-3 h-3 text-white fill-white" />
                <span className="text-[9px] font-black text-white uppercase tracking-widest">Module Predictor Elite</span>
              </div>
              <h2 className="text-4xl sm:text-5xl font-black text-white uppercase tracking-tighter leading-[0.9] mb-4">
                Predictor <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-kls-orange to-kls-yellow">Elite Pulse</span>
              </h2>
              <p className="text-sm text-slate-400 font-medium max-w-md leading-relaxed">
                {!state.syncedPlatform 
                  ? "Veuillez synchroniser un vecteur plateforme pour débloquer l'analyse probabiliste SHA-512."
                  : `Connecté via ${activePlatform?.name}. Prêt pour l'analyse tactique du moteur ${state.syncedEngine}.`
                }
              </p>
            </div>

            <div className="relative z-10 flex items-center justify-between mt-10">
               <div className="flex items-center gap-4">
                 <div className={`w-16 h-16 rounded-full border border-white/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-500 shadow-glow ${state.syncedPlatform ? 'bg-kls-orange/20 text-kls-orange' : 'bg-white/5 text-slate-600'}`}>
                    <PlayCircle className="w-8 h-8" />
                 </div>
                 <div className="space-y-1">
                   <span className="block text-xs font-black text-white uppercase tracking-widest">
                     {state.syncedPlatform ? "Initialiser le Scanner Pro" : "Liaison Requise"}
                   </span>
                   <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                     {state.syncedPlatform ? "Accès : Autorisé" : "Accès : Restreint"}
                   </span>
                 </div>
               </div>
               <ArrowUpRight className="w-8 h-8 text-slate-600 group-hover:text-kls-orange group-hover:-translate-y-2 group-hover:translate-x-2 transition-all duration-500" />
            </div>
          </div>
        </div>

        {/* 4. PLATFORM LINK STATUS */}
        <div className="lg:col-span-1 glass-card rounded-[3rem] border-white/10 p-8 flex flex-col relative overflow-hidden">
          <div className="flex justify-between items-start mb-6">
             <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                <Server className="w-6 h-6 text-kls-cyan" />
             </div>
             <button onClick={syncPlatform} className="p-2 hover:bg-white/5 rounded-xl transition-colors">
               <RefreshCw className="w-5 h-5 text-slate-500 hover:text-white transition-colors" />
             </button>
          </div>
          
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 my-4">
             {activePlatform ? (
               <div className="relative animate-fade-in">
                 <div className="absolute inset-0 bg-kls-cyan/30 blur-2xl rounded-full animate-pulse"></div>
                 <img src={activePlatform.logo} className="w-24 h-24 object-contain relative z-10 drop-shadow-2xl" alt="Platform" />
               </div>
             ) : (
               <div className="w-24 h-24 rounded-full bg-slate-900 border-2 border-dashed border-slate-700 flex items-center justify-center">
                 <Lock className="w-8 h-8 text-slate-600" />
               </div>
             )}
             <div className="min-w-0 w-full px-2">
               <h3 className="text-xl font-black text-white uppercase tracking-tight truncate">
                 {activePlatform ? activePlatform.name : 'Vecteur non lié'}
               </h3>
               <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">
                 {activePlatform ? `Liaison ${state.syncedEngine} Stable` : 'Synchronisation Requise'}
               </p>
             </div>
          </div>

          <button 
            onClick={syncPlatform}
            className={`w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all border ${
              activePlatform 
              ? 'bg-kls-cyan/10 text-kls-cyan border-kls-cyan/20 hover:bg-kls-cyan/20' 
              : 'bg-white/5 text-slate-400 border-white/5 hover:bg-white/10'
            }`}
          >
            {activePlatform ? 'Modifier la Source' : 'Liaison Serveur'}
          </button>
        </div>
      </div>

      {/* 5. SECONDARY MODULES GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        
        {/* Module: DIRECT SEED SCAN */}
        <button onClick={() => onNavigate('direct_analysis')} className="lg:col-span-3 glass-card p-10 rounded-[3rem] border-emerald-500/20 bg-emerald-500/5 hover:bg-emerald-500/10 hover:border-emerald-500/40 transition-all text-left group relative overflow-hidden">
           <div className="absolute top-0 right-0 p-8 opacity-[0.05] group-hover:rotate-12 transition-transform duration-700">
             <FileKey className="w-32 h-32" />
           </div>
           <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-emerald-500/10">
             <ShieldCheck className="w-7 h-7" />
           </div>
           <div className="space-y-1">
             <span className="block text-[11px] font-black text-emerald-500 uppercase tracking-[0.3em] mb-2">Protocole SHA-512</span>
             <span className="block text-2xl font-black text-white uppercase tracking-tight group-hover:text-emerald-300 transition-colors">Direct Seed Scan</span>
             <p className="text-[10px] text-slate-500 font-bold uppercase mt-2 max-w-[200px]">Analyse autonome via fenêtre Provably Fair</p>
           </div>
        </button>

        {/* Module: Assistant IA */}
        <button onClick={() => onNavigate('ai')} className="lg:col-span-3 glass-card p-10 rounded-[3rem] border-white/5 hover:border-kls-cyan/30 hover:bg-white/5 transition-all text-left group relative overflow-hidden">
           <div className="w-12 h-12 rounded-xl bg-kls-cyan/10 flex items-center justify-center text-kls-cyan mb-6 group-hover:scale-110 transition-transform">
             <MessageSquare className="w-6 h-6" />
           </div>
           <span className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Module Neural</span>
           <span className="block text-xl font-black text-white uppercase tracking-tight group-hover:text-kls-cyan transition-colors">Tactique IA</span>
        </button>

        {/* Module: Dashboard */}
        <button onClick={() => onNavigate('dashboard')} className="lg:col-span-2 glass-card p-6 rounded-[2rem] border-white/5 hover:border-kls-orange/30 hover:bg-white/5 transition-all text-left group">
           <div className="w-10 h-10 rounded-xl bg-kls-orange/10 flex items-center justify-center text-kls-orange mb-4 group-hover:scale-110 transition-transform">
             <Activity className="w-5 h-5" />
           </div>
           <span className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">RNG Analytics</span>
           <span className="block text-sm font-black text-white uppercase tracking-tight group-hover:text-kls-orange transition-colors">Télémétrie</span>
        </button>

        {/* Module: Live Chat */}
        <button onClick={() => onNavigate('chat')} className="lg:col-span-2 glass-card p-6 rounded-[2rem] border-white/5 hover:border-emerald-500/30 hover:bg-white/5 transition-all text-left group">
           <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 mb-4 group-hover:scale-110 transition-transform">
             <Headset className="w-5 h-5" />
           </div>
           <span className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Support VIP</span>
           <span className="block text-sm font-black text-white uppercase tracking-tight group-hover:text-emerald-500 transition-colors">Lounge Live</span>
        </button>

        {/* Module: Settings */}
        <button onClick={() => onNavigate('settings')} className="lg:col-span-2 glass-card p-6 rounded-[2rem] border-white/5 hover:border-amber-500/30 hover:bg-white/5 transition-all text-left group">
           <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 mb-4 group-hover:scale-110 transition-transform">
             <Settings className="w-5 h-5" />
           </div>
           <span className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Noyau Système</span>
           <span className="block text-sm font-black text-white uppercase tracking-tight group-hover:text-amber-400 transition-colors">Configuration</span>
        </button>
      </div>

      <div className="flex items-center gap-4 p-6 rounded-[2rem] bg-slate-900 border border-white/5 relative overflow-hidden">
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-kls-cyan animate-pulse"></div>
        <Shield className="w-6 h-6 text-slate-600 flex-shrink-0" />
        <p className="text-[10px] font-black text-slate-500 uppercase leading-relaxed tracking-wide">
          <span className="text-white">Opérateur: {state.currentUser}</span> • Système Elite v11 • <span className="text-kls-cyan">Moteur Neural Stable</span>
        </p>
      </div>
    </div>
  );
};

export default HomeView;
