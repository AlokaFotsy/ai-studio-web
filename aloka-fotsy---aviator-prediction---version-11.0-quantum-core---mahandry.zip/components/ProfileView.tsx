
import React, { useState } from 'react';
import { ChevronLeft, ShieldCheck, Key, User, Save, AlertTriangle, Fingerprint, Lock } from 'lucide-react';
import { AppState } from '../types.ts';
import { useToast } from './ToastProvider.tsx';

interface ProfileViewProps {
  onBack: () => void;
  state: AppState;
  updateCredentials: (newId: string, newPass: string) => void;
}

const VALID_CODES = ['210405', '160808'];

const ProfileView: React.FC<ProfileViewProps> = ({ onBack, state, updateCredentials }) => {
  const { showToast } = useToast();
  const [newId, setNewId] = useState(state.currentUser || '');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [activationCode, setActivationCode] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (newId.trim().length < 4) {
      setError("L'IDENTIFIANT EST TROP COURT (MIN 4).");
      return;
    }

    if (newPass.length < 4) {
      setError("LE MOT DE PASSE EST TROP COURT (MIN 4).");
      return;
    }

    if (newPass !== confirmPass) {
      setError("LES MOTS DE PASSE NE CORRESPONDENT PAS.");
      return;
    }

    if (!VALID_CODES.includes(activationCode)) {
      setError("CODE D'ACTIVATION INCORRECT. VÉRIFIER VOTRE CODE DE SÉCURITÉ.");
      return;
    }

    updateCredentials(newId, newPass);
    showToast("MODIFICATIONS ENREGISTRÉES ET APPLIQUÉES IMMÉDIATEMENT.", "success");
    onBack();
  };

  return (
    <div className="max-w-md mx-auto space-y-8 animate-fade-in pb-20">
      <header className="flex items-center gap-5">
        <button onClick={onBack} className="p-3 glass-card rounded-2xl text-kls-cyan hover:bg-white/10 transition-all shadow-xl">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-2xl font-black text-white uppercase tracking-tight animated-gradient-text">Sécurité <span className="text-kls-cyan">Profil</span></h1>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em]">Modifier les accès du portail</p>
        </div>
      </header>

      <div className="glass-card p-8 rounded-[3rem] border-white/10 bg-slate-900/50 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-[0.05]">
           <ShieldCheck className="w-32 h-32 text-emerald-500" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Identifiant Système (ID)</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-slate-600 group-focus-within:text-kls-cyan transition-colors" />
              </div>
              <input 
                type="text" 
                value={newId} 
                onChange={e => setNewId(e.target.value)}
                placeholder="EX: ELITE_OP_2025"
                className="block w-full h-14 bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 text-sm font-black text-white uppercase outline-none focus:border-kls-cyan/50 transition-all placeholder:text-slate-800"
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Nouveau mot de passe</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Key className="h-5 w-5 text-slate-600 group-focus-within:text-kls-cyan transition-colors" />
              </div>
              <input 
                type="password" 
                value={newPass} 
                onChange={e => setNewPass(e.target.value)}
                placeholder="MOT DE PASSE"
                className="block w-full h-14 bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 text-sm font-black text-white outline-none focus:border-kls-cyan/50 transition-all placeholder:text-slate-800"
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Confirmer le mot de passe</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <ShieldCheck className="h-5 w-5 text-slate-600 group-focus-within:text-emerald-500 transition-colors" />
              </div>
              <input 
                type="password" 
                value={confirmPass} 
                onChange={e => setConfirmPass(e.target.value)}
                placeholder="RÉPÉTER LE PASSE"
                className="block w-full h-14 bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 text-sm font-black text-white outline-none focus:border-emerald-500/50 transition-all placeholder:text-slate-800"
                required
              />
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-white/5">
            <label className="text-[10px] font-black text-rose-500 uppercase tracking-widest ml-1 flex items-center gap-2">
              <Lock className="w-3 h-3" /> Confirmation de Sécurité
            </label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Fingerprint className="h-5 w-5 text-rose-600 group-focus-within:text-white transition-colors" />
              </div>
              <input 
                type="text" 
                value={activationCode} 
                onChange={e => setActivationCode(e.target.value)}
                placeholder="CODE D'ORIGINE REQUIS"
                className="block w-full h-14 bg-rose-500/5 border border-rose-500/20 rounded-2xl pl-12 pr-4 text-sm font-black text-white text-center outline-none focus:border-rose-500/50 transition-all placeholder:text-slate-800 font-mono"
                required
              />
            </div>
          </div>

          {error && (
            <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center gap-3 text-rose-500 animate-shake">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <p className="text-[10px] font-black uppercase tracking-tight">{error}</p>
            </div>
          )}

          <div className="pt-4">
            <button type="submit" className="w-full h-16 bg-white text-black rounded-2xl flex items-center justify-center gap-4 text-sm font-black uppercase shadow-2xl hover:bg-gray-100 transition-all group active:scale-95">
              <Save className="w-6 h-6 group-hover:scale-110 transition-transform" />
              Mettre à jour les accès
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfileView;
