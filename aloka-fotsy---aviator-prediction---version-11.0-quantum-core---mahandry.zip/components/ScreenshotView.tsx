
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  ChevronLeft, Upload, RefreshCcw, Loader2, Activity,
  TrendingUp, Star, ShieldAlert, Copy, AlertCircle,
  Globe, Camera, X, RotateCcw, Sparkles
} from 'lucide-react';
import { analyzeScreenshot } from '../services/gemini.ts';
import { Prediction, AppState } from '../types.ts';
import { useToast } from './ToastProvider.tsx';
import { PLATFORMS } from '../constants.ts';

interface ScreenshotViewProps {
  onBack: () => void;
  state: AppState;
  addPrediction: (p: Prediction) => void;
  onSwitchPlatform: () => void;
}

const getMadagascarTime = () => new Intl.DateTimeFormat('fr-FR', {
  hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Indian/Antananarivo'
}).format(new Date());

const generateHash = () => {
  const chars = '0123456789abcdef';
  return Array.from({ length: 128 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
};

const ScreenshotView: React.FC<ScreenshotViewProps> = ({ onBack, state, addPrediction, onSwitchPlatform }) => {
  const { showToast } = useToast();
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [mode, setMode] = useState<'bonne' | 'mauvaise' | 'rose'>('bonne');
  const [currentTime, setCurrentTime] = useState(getMadagascarTime());
  const [isCameraActive, setIsCameraActive] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const activePlatform = PLATFORMS.find(p => p.id === state.syncedPlatform);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(getMadagascarTime()), 1000);
    return () => clearInterval(timer);
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  }, []);

  const startCamera = async () => {
    try {
      setAnalysisError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      showToast("Accès caméra impossible.", "error");
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        stopCamera();
        runAnalysis(dataUrl);
      }
    }
  };

  const calculateTargetTime = (baseTime: string, minToAdd: number, secToAdd: number) => {
    try {
      const parts = baseTime.split(':');
      const h = Number(parts[0]);
      const m = Number(parts[1]);
      const s = Number(parts[2] || 0);
      const date = new Date();
      date.setHours(h, m, s);
      date.setMinutes(date.getMinutes() + minToAdd);
      const drift = Math.floor(Math.random() * 4);
      date.setSeconds(s + secToAdd + drift);
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    } catch (e) { return baseTime; }
  };

  const getRandInRange = (min: number, max: number) => (Math.random() * (max - min) + min).toFixed(2);

  const runAnalysis = async (imgData: string) => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const base64 = imgData.split('base64,')[1];
      const jsonStr = await analyzeScreenshot(base64);
      const data = JSON.parse(jsonStr);
      if (!data.lastMultiplier || !data.lastTime) throw new Error("Capture illisible.");

      const mult = parseFloat(data.lastMultiplier);
      let res1: any = null;
      let res2: any = null;

      if (mode === 'bonne') {
        if (mult < 2.00 || mult > 10.00) throw new Error(`${mult}x hors norme pour mode BON.`);
        res1 = { time: calculateTargetTime(data.lastTime, 2, 45), multiplier: getRandInRange(2.00, 4.00), label: 'SORTIE SÉCURISÉE', confidence: 98 };
        res2 = { time: calculateTargetTime(data.lastTime, 4, 25), multiplier: getRandInRange(2.00, 10.00), label: 'REPLI TACTIQUE', confidence: 96 };
      } else if (mode === 'mauvaise') {
        if (mult < 2.00 || mult > 5.99) throw new Error(`${mult}x hors norme pour mode MAUVAISE.`);
        res1 = { time: calculateTargetTime(data.lastTime, 1, 55), multiplier: getRandInRange(2.00, 4.00), label: 'RETRAIT RAPIDE', confidence: 97 };
        res2 = { time: calculateTargetTime(data.lastTime, 5, 2), multiplier: getRandInRange(2.00, 8.00), label: 'SIGNAL RISQUÉ', confidence: 94 };
      } else if (mode === 'rose') {
        if (mult < 10.00 || mult > 30.99) throw new Error(`${mult}x hors norme pour mode ROSE.`);
        res1 = { time: calculateTargetTime(data.lastTime, 2, 5), multiplier: getRandInRange(3.00, 10.00), label: 'IMPULSION ROSE', confidence: 99 };
        res2 = { time: calculateTargetTime(data.lastTime, 4, 22), multiplier: getRandInRange(3.00, 15.00), label: 'VECTEUR ROSE', confidence: 95 };
      }

      const p: Prediction = {
        id: Date.now().toString(),
        platform: state.syncedPlatform || 'AVIATOR',
        timestamp: new Date().toISOString(),
        inputTime: data.lastTime,
        inputMultiplier: data.lastMultiplier,
        mode: mode.toUpperCase() as any,
        hash: generateHash(),
        results: { res1, res2 },
        audit: { roundId: data.lastRoundId || "N/A" }
      };

      setPrediction(p);
      addPrediction(p);
      showToast("SIGNATURE NEURAL DÉTECTÉE", "success");
    } catch (err: any) {
      setAnalysisError(err.message);
      showToast("Erreur d'analyse", "error");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const clear = () => { setImage(null); setAnalysisError(null); setPrediction(null); };

  const modeConfig = {
    bonne: { label: 'BON', color: 'text-kls-cyan', bg: 'bg-kls-cyan/10', icon: TrendingUp },
    mauvaise: { label: 'MAUVAISE', color: 'text-rose-500', bg: 'bg-rose-500/10', icon: ShieldAlert },
    rose: { label: 'ROSE', color: 'text-kls-yellow', bg: 'bg-kls-yellow/10', icon: Star }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-24 px-1">
      <header className="flex items-center justify-between gap-4 glass-card p-3 rounded-2xl border-none">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2.5 bg-white/5 rounded-xl text-kls-orange active:scale-95 transition-all shadow-lg">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3 px-3 py-1 bg-white/5 rounded-xl">
            {activePlatform?.logo && <img src={activePlatform.logo} className="w-5 h-5 object-contain" alt="" />}
            <span className="text-[10px] font-black text-white uppercase truncate max-w-[80px]">{activePlatform?.name || 'Aviator'}</span>
          </div>
        </div>
        <div className="bg-slate-950/80 px-3 py-1 rounded-lg">
          <span className="text-[9px] font-mono font-bold text-kls-orange">{currentTime}</span>
        </div>
      </header>

      {!prediction ? (
        <div className="max-w-xl mx-auto space-y-6">
          <div className="grid grid-cols-3 gap-2">
            {(Object.entries(modeConfig) as [keyof typeof modeConfig, any][]).map(([key, cfg]) => {
              const Icon = cfg.icon;
              const isActive = mode === key;
              return (
                <button key={key} onClick={() => { setMode(key); setAnalysisError(null); }} className={`p-4 rounded-xl transition-all duration-300 flex flex-col items-center gap-1.5 ${isActive ? `bg-white/10 scale-105 shadow-md` : 'bg-white/5 opacity-40'}`}>
                  <Icon className={`w-4 h-4 ${isActive ? cfg.color : 'text-slate-500'}`} />
                  <span className={`text-[8px] font-black uppercase ${isActive ? 'text-white' : 'text-slate-400'}`}>{cfg.label}</span>
                </button>
              );
            })}
          </div>

          <div className={`glass-card h-[320px] border-2 border-dashed rounded-3xl relative overflow-hidden flex flex-col items-center justify-center transition-all duration-500 ${image || isCameraActive ? 'border-kls-orange/40 shadow-xl' : 'border-white/10 hover:border-kls-orange/30'}`}>
            {isCameraActive ? (
              <div className="relative w-full h-full">
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4">
                  <button onClick={capturePhoto} className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-2xl active:scale-90 transition-all"><div className="w-10 h-10 rounded-full border-4 border-black"></div></button>
                  <button onClick={stopCamera} className="w-14 h-14 bg-rose-500 text-white rounded-full flex items-center justify-center shadow-2xl active:scale-90 transition-all"><X className="w-6 h-6" /></button>
                </div>
              </div>
            ) : analysisError ? (
              <div className="p-8 text-center space-y-5">
                <AlertCircle className="w-10 h-10 text-rose-500 mx-auto" />
                <p className="text-[9px] text-rose-500/80 font-bold uppercase">{analysisError}</p>
                <div className="flex flex-col gap-2">
                  <button onClick={() => image && runAnalysis(image)} className="h-10 px-6 bg-white text-black rounded-lg text-[9px] font-black uppercase flex items-center justify-center gap-2"><RotateCcw className="w-3 h-3" /> Réessayer</button>
                  <button onClick={clear} className="h-10 px-6 bg-white/5 rounded-lg text-[9px] font-black uppercase text-slate-400">Scanner Autre</button>
                </div>
              </div>
            ) : image ? (
              <div className="relative w-full h-full p-4 overflow-hidden">
                <img src={image} className={`w-full h-full object-contain rounded-xl ${isAnalyzing ? 'opacity-40 blur-sm' : ''}`} alt="" />
                {isAnalyzing && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Loader2 className="w-10 h-10 text-kls-orange animate-spin mb-2" />
                    <span className="text-[9px] font-black uppercase text-kls-orange tracking-widest animate-pulse">Neural Sync...</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center space-y-6 p-6">
                <div className="flex justify-center gap-6">
                  <button onClick={() => fileInputRef.current?.click()} className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center hover:bg-kls-orange/10 transition-all shadow-lg"><Upload className="w-8 h-8 text-slate-600" /></button>
                  <button onClick={startCamera} className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center hover:bg-kls-cyan/10 transition-all shadow-lg"><Camera className="w-8 h-8 text-slate-600" /></button>
                </div>
                <div>
                  <h3 className="text-xs font-black text-white uppercase tracking-widest">Scanner de Flux</h3>
                  <p className="text-[8px] text-slate-500 font-bold uppercase mt-1">Prendre photo ou Importer</p>
                </div>
              </div>
            )}
            <input type="file" ref={fileInputRef} onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const reader = new FileReader();
                reader.onloadend = () => { setImage(reader.result as string); runAnalysis(reader.result as string); };
                reader.readAsDataURL(file);
              }
            }} accept="image/*" className="hidden" />
            <canvas ref={canvasRef} className="hidden" />
          </div>
        </div>
      ) : (
        <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
          {/* ANALYSIS HEADER - ENRICHED APPEARANCE */}
          <div className="glass-card p-6 rounded-3xl bg-slate-900 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6 animate-reveal-data">
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${modeConfig[mode].bg}`}>
                <Activity className={`w-5 h-5 ${modeConfig[mode].color} animate-pulse`} />
              </div>
              <div>
                <span className={`text-[8px] font-black uppercase block ${modeConfig[mode].color} tracking-widest`}>Extraction Neural Terminée</span>
                <h2 className="text-xs font-black text-white uppercase tracking-tight">VECTEURS DE SORTIE CALCULÉS</h2>
              </div>
            </div>
            <div className="flex gap-2">
               <div className="bg-white/5 p-3 rounded-xl text-center min-w-[90px]">
                  <span className="text-[8px] font-black text-slate-600 uppercase block mb-0.5">Crash Input</span>
                  <span className={`text-xs font-mono font-bold ${modeConfig[mode].color}`}>{prediction.inputMultiplier}x</span>
               </div>
            </div>
          </div>

          {/* RESULTS GRID - SEQUENTIAL REVEAL ANIMATIONS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {[prediction.results.res1, prediction.results.res2].filter(Boolean).map((res: any, i) => (
              <div 
                key={i} 
                className="glass-card p-6 rounded-3xl shadow-xl space-y-5 group hover:bg-white/5 transition-all animate-reveal-data"
                style={{ animationDelay: `${(i + 1) * 200}ms` }}
              >
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <span className={`text-[10px] font-black uppercase tracking-widest ${i === 0 ? modeConfig[mode].color : 'text-kls-yellow'}`}>{res.label}</span>
                  <div className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-emerald-400" />
                    <span className="text-[8px] font-black text-slate-400 uppercase">{res.confidence}% Confiance</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="px-5 py-4 bg-slate-950/50 rounded-2xl flex items-center justify-between shadow-inner">
                    <span className="text-[9px] text-slate-600 font-black uppercase">Prévu à</span>
                    <span className="text-lg font-black font-mono text-white tracking-widest">{res.time}</span>
                  </div>
                  
                  <div className={`p-8 rounded-3xl text-center relative overflow-hidden transition-all duration-700 animate-hologram ${i === 0 ? modeConfig[mode].bg : 'bg-kls-yellow/5'}`}>
                    <div className="flex justify-between items-center mb-2">
                       <span className="text-[10px] text-slate-500 font-black uppercase">Multiplier</span>
                       <button onClick={() => { navigator.clipboard.writeText(res.multiplier); showToast("COPIÉ", "info"); }} className="p-2 bg-white/5 rounded-lg hover:bg-white/10 transition-all"><Copy className="w-3.5 h-3.5 text-slate-400" /></button>
                    </div>
                    <div className="flex items-baseline justify-center gap-1">
                      <span className={`text-3xl font-black text-white text-glow-animate ${i === 0 ? modeConfig[mode].color : 'text-kls-yellow'}`}>{res.multiplier}</span>
                      <span className="text-lg text-slate-600 font-black font-mono">x</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-6 animate-reveal-data" style={{ animationDelay: '600ms' }}>
            <button onClick={clear} className="flex-1 h-14 bg-kls-orange text-white font-black uppercase rounded-2xl flex items-center justify-center gap-3 border-none shadow-xl group transition-all active:scale-95">
              <RefreshCcw className="w-5 h-5 text-white group-hover:rotate-180 transition-transform" /> 
              <span className="text-[9px] tracking-widest">Nouveau Calcul</span>
            </button>
            <button onClick={onBack} className="flex-1 h-14 bg-white/5 text-slate-400 font-black uppercase rounded-2xl flex items-center justify-center border-none shadow-xl text-[9px] tracking-widest hover:bg-white/10 transition-colors">
              Retour Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default React.memo(ScreenshotView);
