
import React, { useState, useRef } from 'react';
import { ChevronLeft, Upload, CheckCircle2, XCircle, Trash2, Image as ImageIcon, Loader2 } from 'lucide-react';
import { useToast } from './ToastProvider.tsx';

interface WallpaperSelectorViewProps {
  onBack: () => void;
  onSelect: (wallpaper: string | null) => void;
  currentWallpaper: string | null;
  isFirstLaunch?: boolean;
}

const WallpaperSelectorView: React.FC<WallpaperSelectorViewProps> = ({ onBack, onSelect, currentWallpaper, isFirstLaunch }) => {
  const { showToast } = useToast();
  const [preview, setPreview] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      showToast("Format invalide ! JPG, PNG ou WEBP uniquement.", "error");
      return;
    }
    setIsProcessing(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
      setIsProcessing(false);
    };
    reader.readAsDataURL(file);
  };

  const handleConfirm = () => {
    onSelect(preview || currentWallpaper);
  };

  return (
    <div className={`h-full w-full flex flex-col items-center justify-center p-6 ${isFirstLaunch ? 'animate-fade-in' : ''}`}>
      <div className="w-full max-w-xl glass-card rounded-3xl p-8 space-y-8 relative overflow-hidden">
        {isFirstLaunch && (
          <div className="text-center space-y-2 mb-4">
             <h1 className="text-xl font-black text-white uppercase tracking-tighter">Initialisation Visuelle</h1>
             <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Choisissez un environnement avant de continuer</p>
          </div>
        )}
        
        {!isFirstLaunch && (
          <button onClick={onBack} className="absolute top-6 left-6 p-2 bg-white/5 rounded-lg">
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}

        <div 
          className={`relative h-64 w-full rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center overflow-hidden ${preview || currentWallpaper ? 'border-kls-cyan' : 'border-white/10 hover:border-kls-cyan/30'}`}
          onClick={() => fileInputRef.current?.click()}
        >
          {isProcessing ? (
            <Loader2 className="w-8 h-8 animate-spin text-kls-cyan" />
          ) : preview || currentWallpaper ? (
            <img src={preview || currentWallpaper!} className="w-full h-full object-cover" alt="" />
          ) : (
            <div className="text-center space-y-2">
              <Upload className="w-8 h-8 text-slate-600 mx-auto" />
              <span className="text-[10px] font-black uppercase text-slate-500">Importer Image</span>
            </div>
          )}
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
        </div>

        <div className="space-y-3">
          <button 
            onClick={handleConfirm}
            className="w-full h-14 bg-white text-black font-black rounded-xl uppercase text-xs shadow-xl transition-all active:scale-95"
          >
            {isFirstLaunch ? "Accepter & Continuer" : "Appliquer"}
          </button>
          
          {(preview || currentWallpaper) && (
            <button 
              onClick={() => { setPreview(null); onSelect(null); }}
              className="w-full h-14 bg-rose-500/10 text-rose-500 font-black rounded-xl uppercase text-xs"
            >
              Réinitialiser
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default WallpaperSelectorView;
